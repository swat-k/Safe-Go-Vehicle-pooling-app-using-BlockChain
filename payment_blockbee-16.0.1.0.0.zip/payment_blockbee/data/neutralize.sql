-- disable BlockBee payment provider
UPDATE payment_provider
   SET blockbee_api_key = NULL